module.exports = {
  ...require('mwts/.prettierrc.json')
}
